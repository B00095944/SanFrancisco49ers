<?php
$nameErr = "";
$passErr = "";

$pass = filter_input(INPUT_POST, 'psw');
$name = filter_input(INPUT_POST, 'name');

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["name"])){
        echo $nameErr = "No name entered <br>";
    }
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    if($_POST["psw"] != "admin"){
        echo $passErr = "error, invalid password";
    }
}

if(!$nameErr && !$passErr)
{
    $pageTitle="Admin View";
    include __DIR__ . '/../views/adminView.html';
}