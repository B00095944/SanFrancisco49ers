<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:00
 */

namespace Itb;


class WebApplication
{
    private $mainController;

    /**
     * WebApplication constructor.
     * @param $mainController
     */
    public function __construct()
    {
        $this->mainController = new MainController();
    }


    public function run()
    {
        $action = filter_input(INPUT_GET, 'action');

        switch ($action) {
            case'about':
                $this->mainController->aboutAction();
                break;

            case'shop':
                $this->mainController->shopAction();
                break;

            case'gallery':
                $this->mainController->galleryAction();
                break;

            case'login':
                $this->mainController->loginAction();
                break;

            case'signup':
                $this->mainController->signUpAction();
                break;

            case'emailSignUp':
                $this->mainController->emailSignUpAction();
                break;

            case 'home':
            default:
                $this->mainController->homeAction();
        }
    }

}