<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:02
 */

namespace Itb;


class MainController
{
    public function homeAction()
    {
        $pageTitle = 'Home';
        include __DIR__ . '/../views/home.html';
    }

    public function aboutAction()
    {
        $pageTitle = 'About';
        include __DIR__ . '/../views/about.html';
    }

    public function shopAction()
    {
        $pageTitle = 'Shop';
        include __DIR__ . '/../views/shop.html';
    }

    public function galleryAction()
    {
        $pageTitle = 'Gallery';
        include __DIR__ . '/../views/gallery.html';
    }

    public function loginAction()
    {
        $pageTitle = 'Login';
        include __DIR__ . '/../views/login.html';
    }

    public function signUpAction()
    {
        $pageTitle = 'SignUp';
        include __DIR__ . '/../views/signup.html';
    }

    public function emailSignUpAction()
    {
        include __DIR__ . '/../processes/emailSignUp.php';
    }

    public function adminSignInAction()
    {
        $pageTitle = 'Admin SignIn';
        include __DIR__ . '/../views/adminSignIn.html';
    }

    public function staffSignInAction()
    {
        $pageTitle = 'Staff SignIn';
        include __DIR__ . '/../views/staffSignIn.html';
    }

    public function adminAuthenticateAction()
    {
        include __DIR__ . '/../processes/adminAuthenticate.php';
    }

    public function staffAuthenticateAction()
    {
        include __DIR__ . '/../processes/staffAuthenticate.php';
    }

    public function staffViewAction()
    {
        $pageTitle = 'Staff View';
        include __DIR__ . '/../views/staffView.html';
    }

    public function adminViewAction()
    {
        $pageTitle = 'Admin View';
        include __DIR__ . '/../views/adminView.html';
    }

    public function staffAddProductFormAction()
    {
        $pageTitle = 'Add Product';
        include __DIR__ . '/../views/staffAddProduct.html';
    }

    public function staffAddProductProcessAction()
    {
        include __DIR__ . '/../processes/staffAddProduct.php';
    }

    public function adminAddProductFormAction()
    {
        $pageTitle = 'Add Product';
        include __DIR__ . '/../views/adminAddProduct.html';
    }

    public function adminAddProductProcessAction()
    {
        include __DIR__ . '/../processes/adminAddProduct.php';
    }

    public function showProductListAction()
    {
        $pageTitle = 'Show Product List';
        include __DIR__ . '/../views/showProductList.html';
    }

    public function showStaffListAction()
    {
        $pageTitle = 'Show Staff List';
        include __DIR__ . '/../views/showStaffList.html';
    }

    public function showEmailSubsAction()
    {
        $pageTitle = 'Show Email Subscribers';
        include __DIR__ . '/../views/showEmailSubscribers.html';
    }

    public function addStaffFormAction()
    {
        $pageTitle = 'Add Staff';
        include __DIR__ . '/../views/addStaff.html';
    }

    public function addStaffProcessAction()
    {
        include __DIR__ . '/../processes/addStaff.php';
    }

    public function removeStaffFormAction()
    {
        $pageTitle = 'Remove Staff';
        include __DIR__ . '/../views/removeStaff.html';
    }



}