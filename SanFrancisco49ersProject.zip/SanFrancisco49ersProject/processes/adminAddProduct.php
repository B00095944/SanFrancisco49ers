<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Itb\Product;
use Itb\ProductRepository;

$name = filter_input(INPUT_POST, 'name');
$description = filter_input(INPUT_POST,'description');
$price = filter_input(INPUT_POST,'price');
$quantity = filter_input(INPUT_POST, 'quantity');

$p = new Product();

$p->setTitle($name);
$p->setDescription($description);
$p->setPrice($price);
$p->setQuantity($quantity);

$productRepository = new ProductRepository();
$productRepository->createTable();

$productRepository->insertProduct($p);

echo "Product Inserted, please click the link to return to the home page: <a href=\"/index.php?action=adminView\">Click here</a>";
