<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:02
 */

namespace Itb;


class MainController
{
    private $twig;

    public function __construct($twig)
    {
        $this->twig = $twig;
    }
    public function homeAction()
    {
        $template = 'home.html.twig';
        $argsArray = [
            'pageTitle' => 'Home'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function aboutAction()
    {
        $template = 'about.html.twig';
        $argsArray = [
            'pageTitle' => 'About'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function shopAction()
    {
        $productRepository = new ProductRepository();
        $product = $productRepository->getAll();
        $template = 'shop.html.twig';
        $argsArray = [
            'pageTitle' => 'Shop',
            'products' => $product
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function galleryAction()
    {
        $template = 'gallery.html.twig';
        $argsArray = [
            'pageTitle' => 'Gallery'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function loginAction()
    {
        $template = 'login.html.twig';
        $argsArray = [
            'pageTitle' => 'Login'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function signUpAction()
    {
        $template = 'signup.html.twig';
        $argsArray = [
            'pageTitle' => 'SignUp'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function emailSignUpAction()
    {
        include __DIR__ . '/../processes/emailSignUp.php';
    }

    public function adminSignInAction()
    {
        $template = 'adminSignIn.html.twig';
        $argsArray = [
            'pageTitle' => 'Admin SignIn'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function staffSignInAction()
    {
        $template = 'staffSignIn.html.twig';
        $argsArray = [
            'pageTitle' => 'Staff SignIn'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function adminAuthenticateAction()
    {
        include __DIR__ . '/../processes/adminAuthenticate.php';
    }

    public function staffAuthenticateAction()
    {
        include __DIR__ . '/../processes/staffAuthenticate.php';
    }

    public function staffViewAction()
    {
        $template = 'staffView.html.twig';
        $argsArray = [
            'pageTitle' => 'Staff'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function adminViewAction()
    {
        $template = 'adminView.html.twig';
        $argsArray = [
            'pageTitle' => 'Admin'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function staffAddProductFormAction()
    {
        $pageTitle = 'Add Product';
        include __DIR__ . '/../views/staffAddProduct.html';
    }

    public function staffAddProductProcessAction()
    {
        include __DIR__ . '/../processes/staffAddProduct.php';
    }

    public function adminAddProductFormAction()
    {
        $template = 'adminAddProduct.html.twig';
        $argsArray = [
            'pageTitle' => 'Admin Add Product'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function adminAddProductProcessAction()
    {
        include __DIR__ . '/../processes/adminAddProduct.php';
    }

    public function showProductListAction()
    {
        $productRepository = new ProductRepository();
        $product = $productRepository->getAll();
        $template = 'showProductList.html.twig';
        $argsArray = [
            'pageTitle' => 'Product List',
            'products' => $product
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function showStaffListAction()
    {
        $staffRepository = new StaffRepository();
        $employee = $staffRepository->getAll();
        $template = 'showStaffList.html.twig';
        $argsArray = [
            'pageTitle' => 'Product List',
            'employees' => $employee
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function showEmailSubsAction()
    {
        $visitorsRepository = new VisitorsRepository();
        $visitor = $visitorsRepository->getAll();
        $template = 'showEmailSubscribers.html.twig';
        $argsArray = [
            'pageTitle' => 'Email Subscribers',
            'visitors' => $visitor
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function addStaffFormAction()
    {
        $template = 'addStaff.html.twig';
        $argsArray = [
            'pageTitle' => 'Admin Add Staff'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }

    public function addStaffProcessAction()
    {
        include __DIR__ . '/../processes/addStaff.php';
    }

    public function removeStaffAction($id)
    {
        $staffRepository = new StaffRepository();
		$staffRepository->deleteOne($id);
		include __DIR__ . '/../views/showStaffList.html.twig';
    }
	
	public function removeProductAction($id)
    {
		$pageTitle = 'Product List';
        $productRepository = new ProductRepository();
		$productRepository->deleteOne($id);
		include __DIR__ . '/../views/showProductList.html.twig';
    }
	
	public function removeSubsAction($id)
    {
		$pageTitle = 'Email Subscribers List';
        $visitorsRepository = new VisitorsRepository();
		$visitorsRepository->deleteOne($id);
		include __DIR__ . '/../views/showEmailSubscribers.html.twig';
    }
	
	public function adminUpdateProductAction($id)
    {
        $productRepository = new ProductRepository();
		$product = $productRepository->getOne($id);
        $template = 'adminUpdateProduct.html.twig';
        $argsArray = [
            'pageTitle' => 'Update Product',
            'product' => $product
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }
	
	public function adminUpdateProductProcessAction($id,$title,$description,$price,$quantity)
    {
        $productRepository = new ProductRepository();

        $productRepository->updateProduct($id,$title,$description,$price,$quantity );

        header("Location : /index.php?action=adminView");
        exit();
    }


    public function setupAction(){
        include_once __DIR__. '/../setup/setupDatabase.php';
    }
	
}