<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:50
 */

namespace Itb;


class VisitorsRepository
{
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS visitors";
        $this->connection->exec($sql);
    }

    public function createTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS visitors (
            id integer not null primary key auto_increment,
            name TEXT,
            surname TEXT,
            address TEXT,
            email TEXT)
        ";

        $this->connection->exec($sql);
    }

    public function insertVisitor(Visitors $v)
    {
        $name = $v->getName();
        $surname = $v->getSurname();
        $address = $v->getAddress();
        $email = $v->getEmail();


        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO visitors (name, surname, address, email) 
			VALUES (:name, :surname, :address, :email)';
        $stmt = $this->connection->prepare($sql);
        // Bind parameters to statement variables
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':surname', $surname);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':email', $email);

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM visitors';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Visitors');

        $visitors = $stmt->fetchAll();

        return $visitors;
    }



}