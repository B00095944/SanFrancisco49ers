<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Itb\Staff;
use Itb\StaffRepository;

$name = filter_input(INPUT_POST, 'name');
$job = filter_input(INPUT_POST,'job');

$s = new Staff();

$s->setName($name);
$s->setJob($job);

$staffRepository = new StaffRepository();
$staffRepository->createTable();

$staffRepository->insertStaff($s);

echo "Staff member has been inserted, please click the link to return to the staff view page: <a href=\"/index.php?action=adminView\">Click here</a>";
