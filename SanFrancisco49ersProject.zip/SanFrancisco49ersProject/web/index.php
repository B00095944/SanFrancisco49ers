<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 31/10/2017
 * Time: 13:47
 */

require_once __DIR__ . "/../vendor/autoload.php";

$app = new Itb\WebApplication;
$app->run();
