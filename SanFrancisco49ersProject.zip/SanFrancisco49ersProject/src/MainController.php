<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:02
 */

namespace Itb;


class MainController
{
    public function homeAction()
    {
        $pageTitle = 'Home';
        include __DIR__ . '/../views/home.html';
    }

    public function aboutAction()
    {
        $pageTitle = 'About';
        include __DIR__ . '/../views/about.html';
    }

    public function shopAction()
    {
        $pageTitle = 'Shop';
        include __DIR__ . '/../views/shop.html';
    }

    public function galleryAction()
    {
        $pageTitle = 'Gallery';
        include __DIR__ . '/../views/gallery.html';
    }

    public function loginAction()
    {
        $pageTitle = 'Login';
        include __DIR__ . '/../views/login.html';
    }

    public function signUpAction()
    {
        $pageTitle = 'SignUp';
        include __DIR__ . '/../views/signup.html';
    }

    public function emailSignUpAction()
    {
        include __DIR__ . '/../processes/emailSignUp.php';
    }

}