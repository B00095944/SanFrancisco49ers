<?php
require_once __DIR__ . '/../vendor/autoload.php';


use Itb\Product;
use Itb\ProductRepository;


$p = new Product();

$p->setTitle('Helmet');
$p->setDescription("Red and Yellow");
$p->setPrice(5);
$p->setQuantity(10);

$productRepository = new ProductRepository();

$productRepository->createTable();

$productRepository->insertProduct($p);


