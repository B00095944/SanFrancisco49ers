<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 14/11/2017
 * Time: 19:00
 */

namespace Itb;


class WebApplication
{
    private $mainController;

    /**
     * WebApplication constructor.
     * @param $mainController
     */
    public function __construct()
    {
        $this->mainController = new MainController();
    }


    public function run()
    {
        $action = filter_input(INPUT_GET, 'action');

        switch ($action) {
            case'about':
                $this->mainController->aboutAction();
                break;

            case'shop':
                $this->mainController->shopAction();
                break;

            case'gallery':
                $this->mainController->galleryAction();
                break;

            case'login':
                $this->mainController->loginAction();
                break;

            case'signup':
                $this->mainController->signUpAction();
                break;

            case'emailSignUp':
                $this->mainController->emailSignUpAction();
                break;

            case'admin':
                $this->mainController->adminSignInAction();
                break;

            case'staff':
                $this->mainController->staffSignInAction();
                break;

            case'staffView':
                $this->mainController->staffViewAction();
                break;

            case'adminView':
                $this->mainController->adminViewAction();
                break;

            case'adminAuthenticate':
                $this->mainController->adminAuthenticateAction();
                break;

            case'staffAuthenticate':
                $this->mainController->staffAuthenticateAction();
                break;

            case'staffAddProductForm':
                $this->mainController->staffAddProductFormAction();
                break;

            case'staffAddProductProcess':
                $this->mainController->staffAddProductProcessAction();
                break;

            case'adminAddProductForm':
                $this->mainController->adminAddProductFormAction();
                break;

            case'adminAddProductProcess':
                $this->mainController->adminAddProductProcessAction();
                break;

            case'showProductList':
                $this->mainController->showProductListAction();
                break;

            case'showStaffList':
                $this->mainController->showStaffListAction();
                break;

            case'showEmailSubs':
                $this->mainController->showEmailSubsAction();
                break;

            case'addStaffForm':
                $this->mainController->addStaffFormAction();
                break;

            case'addStaffProcess':
                $this->mainController->addStaffProcessAction();
                break;

            case'removeStaff':
			    $id = filter_input(INPUT_GET, 'id');
                $this->mainController->removeStaffAction($id);
                break;
				
			case'removeProduct':
			    $id = filter_input(INPUT_GET, 'id');
                $this->mainController->removeProductAction($id);
                break;
				
			case'removeSubs':
			    $id = filter_input(INPUT_GET, 'id');
                $this->mainController->removeSubsAction($id);
                break;
				
			case'adminUpdateProduct':
			    $id = filter_input(INPUT_GET, 'id');
                $this->mainController->adminUpdateProductAction($id);
                break;
				
			case'adminUpdateProductProcess':
			    $id = filter_input(INPUT_GET, 'id');
                $this->mainController->adminUpdateProductProcessAction($id);
                break;
				

            case 'home':
            default:
                $this->mainController->homeAction();
        }
    }

}