<?php
$nameErr = "";
$passErr = "";

$pass = filter_input(INPUT_POST, 'psw');
$name = filter_input(INPUT_POST, 'name');

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["name"])){
        echo $nameErr = "No name entered <br>";
    }
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    if($_POST["psw"] != "staff"){
        echo $passErr = "error, invalid password";
    }
}

if(!$nameErr && !$passErr)
{
    $template = 'staffView.html.twig';
    $argsArray = [
        'pageTitle' => 'Staff'
    ];
    $html = $this->twig->render($template, $argsArray);
    print $html;
}