<?php
require_once __DIR__ . '/../vendor/autoload.php';


use Itb\Product;
use Itb\ProductRepository;

try {

    $productRepository = new ProductRepository();
    $productRepository->createTable();

    $p = new Product();
    $p->setTitle("Helmet");
    $p->setPrice(10);
    $p->setQuantity(3);
    $p->setDescription("Red and Yellow");
    $productRepository->insertProduct($p);

}catch(\PDOException $e){
    print 'error working with pdo database';
}

