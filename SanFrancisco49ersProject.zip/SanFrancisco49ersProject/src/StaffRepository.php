<?php
/**
 * Created by PhpStorm.
 * User: Tim Mc Cann
 * Date: 12/11/2017
 * Time: 14:30
 */

namespace Itb;


class StaffRepository
{
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function createTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS staff(
            id integer not null primary key auto_increment,
            name text,
            job text)
        ";

        $this->connection->exec($sql);
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS staff";
        $this->connection->exec($sql);
    }

    public function insertStaff(Staff $s)
    {
        $name= $s->getName();
        $job = $s->getJob();

        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO staff (name, job) 
			VALUES (:name, :job)';
        $stmt = $this->connection->prepare($sql);

        // Bind parameters to statement variables
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':job', $job);

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM staff';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Staff');

        $products = $stmt->fetchAll();

        return $products;
    }

}