<?php
/**
 * Created by PhpStorm.
 * User: matt
 * Date: 26/10/2017
 * Time: 14:02
 */
namespace Itb;

class ProductRepository
{
    /**
     * @var \PDO
     */
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS products";
        $this->connection->exec($sql);
    }

    public function createTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS products (
            id integer not null primary key auto_increment,
            description TEXT,
            price FLOAT,
            title TEXT,
            quantity INT)
        ";

        $this->connection->exec($sql);
    }

    public function insertProduct(Product $p)
    {
        $title = $p->getTitle();
        $price = $p->getPrice();
        $description = $p->getDescription();
        $quantity = $p->getQuantity();


        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO products (title, description, quantity, price) 
			VALUES (:description, :quantity, :title, :price)';
        $stmt = $this->connection->prepare($sql);
        // Bind parameters to statement variables
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':title', $title);

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM products';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Product');

        $products = $stmt->fetchAll();

        return $products;
    }


}