<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Itb\Visitors;
use Itb\VisitorsRepository;

$name = filter_input(INPUT_POST, 'name');
$surname = filter_input(INPUT_POST,'surname');
$address = filter_input(INPUT_POST,'address');
$email = filter_input(INPUT_POST, 'email');

$v = new Visitors();

$v->setName($name);
$v->setSurname($surname);
$v->setAddress($address);
$v->setEmail($email);

$visitorsRepository = new VisitorsRepository();
$visitorsRepository->createTable();

$visitorsRepository->insertVisitor($v);

echo "Thank you for signing up, please click the link to return to the home page: <a href=\"/index.php?action=home\">Click here</a>";