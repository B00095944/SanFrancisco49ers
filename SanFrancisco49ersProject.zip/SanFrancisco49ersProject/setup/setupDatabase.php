<?php
require_once __DIR__ . '/../vendor/autoload.php';


use Itb\Product;
use Itb\ProductRepository;


$p = new Product();
$p->setTitle("Helmet");
$p->setPrice(10);
$p->setQuantity(3);
$p->setDescription("Red and Yellow");

$productRepository = new ProductRepository();

$productRepository->dropTable();
$productRepository->createTable();
$productRepository->insertProduct($p);


